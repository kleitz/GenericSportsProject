﻿//$(function () {
//    //$('a').click(function () {
//        $('a').attr("href", "http://www.google.com");
//    //});
//});